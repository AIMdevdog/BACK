# BACK
### 손예림, 신민수, 정원종

1. 환경 맞추기 - Git push, pull
   - 개발 도중 새로운 모듈을 설치할 경우 반드시 명령어에 "--save" 추가할 것.
   - ex) npm install --save mysql
   - 새 모듈을 설치한 경우 프로젝트를 pull 하고나서 "npm install" 해줄 것. (package.json의 dependencies의 모든 패키지 버전에 맞게 설치하는 명령어)

2. 구글 로그인

3. 서버 열기

4. 방 연결
